package client;

import client.pallanet.PallaNetServer;

public class MainProgram {

	public static void main(String[] args) {
		PallaNetServer client = new PallaNetServer();
	}
	
}
